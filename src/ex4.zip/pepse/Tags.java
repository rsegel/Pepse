package pepse;
/**
    Enum for tags.
*/
public enum Tags {
    AVATAR,
    TREE,
    FRUIT,
    SKY,
    NIGHT,
    SUN,
    SUN_HALO,
    ENERGY,
    LEAF,
    COLLECTED_FRUIT,
    BLOCK,
    TOP_LAYER_BLOCK,
    UNKNOWN
}

